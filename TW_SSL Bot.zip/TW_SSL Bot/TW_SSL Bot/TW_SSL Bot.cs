﻿using System;
using System.Linq;
using cAlgo.API;
using cAlgo.API.Indicators;
using cAlgo.API.Internals;
using cAlgo.Indicators;

namespace cAlgo.Robots
{
    [Robot(TimeZone = TimeZones.EasternStandardTime, AccessRights = AccessRights.None)]
    public class TW_SSLBot : Robot
    {
        [Parameter("Risk %", DefaultValue = 0.02)]
        public double RiskPct { get; set; }

        [Parameter("SSL Period", DefaultValue = 10)]
        public int SSL_period { get; set; }

        [Parameter("SSL MA Type", DefaultValue = MovingAverageType.Simple)]
        public MovingAverageType SSL_MAT { get; set; }


        //Create indicators
        private AverageTrueRange atr;
        private SSLChannel ssl;

        protected override void OnStart()
        {
            //Load indicators
            atr = Indicators.AverageTrueRange(14, MovingAverageType.Exponential);
            ssl = Indicators.GetIndicator<SSLChannel>(SSL_period, SSL_MAT);

        }

        protected override void OnTick()
        {

            //Two Line Cross
            var SSLup = ssl._sslUp.Last(0);
            var PrevSSLup = ssl._sslUp.Last(1);
            var SSLdown = ssl._sslDown.Last(0);
            var PrevSSLdown = ssl._sslDown.Last(1);

            //Check for signal
            if (SSLup > SSLdown & PrevSSLup < PrevSSLdown)
            {
                Open("SSL Long", TradeType.Buy);
                Close("SSL Short", TradeType.Sell);
            }
            else if (SSLup < SSLdown & PrevSSLup > PrevSSLdown)
            {
                Open("SSL Short", TradeType.Sell);
                Close("SSL Long", TradeType.Buy);

            }

        }

        private void Open(string Label, TradeType TradeDirection)
        {
            //Calculate Trade Amount
            var PrevATRpips = Math.Round(atr.Result.Last(1) / Symbol.PipSize);
            var TradeAmount = (Account.Equity * RiskPct) / (1.5 * PrevATRpips * Symbol.PipValue);
            TradeAmount = Symbol.NormalizeVolumeInUnits(TradeAmount, RoundingMode.Down);

            //Execute Market Order
            if (Server.Time.Hour == 16 & Server.Time.Minute == 29)
                ExecuteMarketOrder(TradeDirection, SymbolName, TradeAmount, Label, 1.5 * PrevATRpips, PrevATRpips);

        }

        private void Close(string Label, TradeType TradeDirection)
        {
            foreach (var position in Positions.FindAll(Label, SymbolName, TradeDirection))
                ClosePosition(position);
        }


        protected override void OnBar()
        {

        }
        protected override void OnStop()
        {
            // Put your deinitialization logic here
        }
    }
}
